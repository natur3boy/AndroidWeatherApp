package com.example.weatherapp.api

object Constant {

    val apiKey = "11e967398b3e4a7d99b192220241510"
}