package com.example.weatherapp.api

data class Condition(
    val code: String,
    val icon: String,
    val text: String
)